@extends('layouts.app')

@section("header")
  @include('partials.header-admin', array('title' => "Artikel aanmaken"))
@endsection

@section("content")
  
@endsection

