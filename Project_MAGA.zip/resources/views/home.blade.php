@extends('layouts.app')

@section("header")
  @include('partials.header-hero', array('title' => "Antwerpen De Beste Studentenstad"))
@endsection

@section("content")
<div class="container">
  
</div>
@endsection
