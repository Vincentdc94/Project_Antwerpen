<div class="header-admin">
    <div class="container">
     <header class="header">
        <div class="float-left">
          <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>" class="logo" alt="Stan Logo">
          </a> 
        </div>
        <div class="float-left">
          <h2>
            <?php echo e($title); ?>

          </h2>
        </div>
        <div class="float-right">
          <?php if($menu === true): ?>
            <div class="menu-holder">
              <div class="menu-search" id="menu-search-button">
                <i class="fa fa-search"></i> 
              </div>
              <div class="menu" id="menu-button">
                <i class="fa fa-navicon"></i> <div class="menu-text">Menu</div>
              </div>
            </div>
          <?php else: ?>
            <button class="button--primary" onclick="window.history.back()">Terug</button>
          <?php endif; ?>
          
        </div>
      </header>
    </div>
</div>