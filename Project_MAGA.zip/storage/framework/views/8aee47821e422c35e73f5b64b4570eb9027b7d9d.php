<div class="navigation" id="navigation">
    <div class="container">
        <div class="row">
            <div class="navigation-title float-left">
                Menu
            </div>

            <div class="navigation-close float-right">
                <i class="fa fa-close" id="navigation-close"></i>
            </div>
        </div>
        
        <div class="row">
            <div class="col-perc-60">
                <ul class="navigation-items">
                    <li><a href="<?php echo e(url('/nieuws')); ?>" class="navigation-item">Nieuws</a></li>
                    <li><a href="<?php echo e(url('/getuigenissen')); ?>" class="navigation-item">Antwerpen Studentenstad</a></li>
                    <li><a href="<?php echo e(url('/')); ?>" class="navigation-item">Antwerpen Biedt aan</a></li>
                    <li><a href="<?php echo e(url('/admin')); ?>" class="navigation-item">Admin</a></li>
                </ul>
            </div>
            <div class="col-perc-40">
                
            </div>
        </div>
    </div>
</div>