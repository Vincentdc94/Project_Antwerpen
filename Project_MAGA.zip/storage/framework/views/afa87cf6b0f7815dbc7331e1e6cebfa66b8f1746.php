<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('partials.header-titled', array('title' => 'Nieuws'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
<div class="container">

<div class="row">
    <div class="col-perc-60-gt-30">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($article); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="news-item box-large">
            <img src="<?php echo e(asset('images/hero.jpg')); ?>" class="news-image" alt="Hero image">
            <div class="news-overlay">
                <div class="news-category"><?php echo e('Categorie'); ?></div>
                <div class="news-title">
                    <h3><?php echo e('Dit is een nieuwstitel'); ?></h3>
                </div>
                <div class="news-button">Lees Artikel</div>
                <div class="news-details">
                    <div class="news-author"><?php echo e('Vincent De Coen'); ?></div>
                    <div class="news-date"><?php echo e('20 April 2017'); ?></div>
                </div>
            </div>
        </div>
        <br />
        <div class="row" style="margin-left: -12.5px; width: 104%;">
            <div class="col-2-gt-30">
            <div class="news-item box-medium">
            <img src="<?php echo e(asset('images/hero.jpg')); ?>" class="news-image" alt="Hero image">
            <div class="news-overlay">
                <div class="news-category"><?php echo e('Categorie'); ?></div>
                <div class="news-title">
                    <h3><?php echo e('Dit is een nieuwstitel'); ?></h3>
                </div>
                <div class="news-button">Lees Artikel</div>
                <div class="news-details">
                    <div class="news-author"><?php echo e('Vincent De Coen'); ?></div>
                    <div class="news-date"><?php echo e('20 April 2017'); ?></div>
                </div>
            </div>
            </div>
            </div>
            <div class="col-2-gt-30">
            <div class="news-item box-medium">
                <img src="<?php echo e(asset('images/hero.jpg')); ?>" class="news-image" alt="Hero image">
                <div class="news-overlay">
                    <div class="news-category"><?php echo e('Categorie'); ?></div>
                    <div class="news-title">
                        <h3><?php echo e('Dit is een nieuwstitel'); ?></h3>
                    </div>
                    <div class="news-button">Lees Artikel</div>
                    <div class="news-details">
                        <div class="news-author"><?php echo e('Vincent De Coen'); ?></div>
                        <div class="news-date"><?php echo e('20 April 2017'); ?></div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="col-perc-40-gt-30">
        <div class="news-item">
            <div class="box-content">
                <h3 class="box-title"><?php echo e('Dit is een nieuwstitel'); ?></h3>
                <p><?php echo e('Dit is een een samenvatting van het artikel. Een inspirerend artikel om de student te overtuigen.'); ?></p>
            </div>
            <div class="box-details align-right">
                <a href="<?php echo e(url('artikel/1')); ?>">Lees Meer...</a>
            </div>
        </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>