<?php $__env->startSection("header"); ?>
  <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="container">
        <h1>Het Mas</h1>
        <div class="slider" id="slider-sight">
            <div class="slider-previous" id="slide-previous">
                <i class="fa fa-chevron-left"></i>
            </div>
            <div class="slider-content">
                <div class="slider-item"><img src="<?php echo e(asset('images/hero.jpg')); ?>" alt="Hero image"></div>
                <div class="slider-item"><img src="<?php echo e(asset('images/angled_dag.png')); ?>" alt="Angled Dag"></div>
                <div class="slider-item"><img src="<?php echo e(asset('images/google-play-badge.png')); ?>" alt="Google Play Badge"></div>
            </div>
            <div class="slider-next" id="slide-next">
                <i class="fa fa-chevron-right"></i>
            </div>
        </div>
        <div class="row">
            <div class="col-perc-60-gt-30">
                <div class="article-content">
                    <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam enim risus, venenatis sed risus a, rhoncus cursus justo. Morbi enim enim, pharetra id ultricies eu, porta sit amet libero. Sed hendrerit ornare nibh, bibendum hendrerit sem molestie sit amet. Integer sit amet vestibulum risus, non porta ex. Vivamus facilisis sapien vitae erat tincidunt, finibus lobortis libero elementum. Morbi ut elit et mauris tempor ultricies in sit amet tellus. Suspendisse potenti. Mauris eget ultricies nunc. Maecenas sit amet leo pulvinar, blandit est eget, dignissim erat. Nullam volutpat varius eros. Curabitur sit amet justo ligula. Morbi risus purus, congue ac nunc vitae, luctus feugiat nunc.
                    </p>
                </div>
            </div>
            <div class="col-perc-40-gt-30">
                <h3>Contact</h3>
                <hr />
                <h2>HET MAS</h2>
                <p>Hanzestedenplaats 1, 2000 Antwerpen</p>
                <p><a href="tel:03 338 44 00">03 338 44 00</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>