<?php $__env->startSection('content'); ?>

<div class="content" id="tim">
  <div class="content-overlay" id="content-overlay"></div>
  <div class="content-overlay" id="content-overlay-2"></div>
  <div class="content-overlay" id="content-overlay-3">

    <div class="content-holder">
      <div class="content-title" id="content-title">Antwarpe</div>
      <div class="content-subtitle" id="content-subtitle">De Schoonste studentenstad</div>
      <p id="start">
        <button class="button--experience" id="start-experience">Begin introductie</button>
        
      </p>
      <p class="hide end" id="end">
        <a href="<?php echo e(url('/')); ?>" class="button--experience">Ontdek Meer op de site</a>
      </p>
    </div>
  </div>
  <img src="" class="hide content-image" id="content-image" alt="Slide image">
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.empty', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>